<?php
    $db_host = 'localhost';
    $db_port = '3306'; 
    $db_user = 'root';
    $db_pass = 'Al04@95annur';
    $db_name = 'pay';
    $db_prefix = 'pp_';
?>